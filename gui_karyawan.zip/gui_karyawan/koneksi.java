/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui_karyawan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author ThinkPad X270
 */
public class koneksi {
    static Connection konek;
    public static Connection koneksiDB(){
        
    try{
    String url ="jdbc:mysql://localhost:3306/db_karyawan";
            String user="root";
            String pass="";            
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            konek= (Connection)DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "koneksi gagal");
        }
        return konek;
    }
    public static void main(String[] args) {
        try{
            Connection c = koneksi.koneksiDB();
            System.out.println(String.format("Connected to database %s " + "successfully", c.getCatalog()));
        }catch(SQLException e){
            System.out.println(e);
        }
    }
}
